rtlsdraio module
================

.. automodule:: rtlsdr.rtlsdraio
    :members: RtlSdrAio, AsyncCallbackIter
    :show-inheritance:
