rtlsdr module
=============

.. automodule:: rtlsdr.rtlsdr
    :members:
    :private-members:
    :show-inheritance:
