.. pyrtlsdr documentation master file, created by
   sphinx-quickstart on Mon Apr 11 13:18:30 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pyrtlsdr's documentation!
====================================

.. toctree::
   :caption: Contents
   :name: mastertoc
   :maxdepth: 3

   Overview
   Reference


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
